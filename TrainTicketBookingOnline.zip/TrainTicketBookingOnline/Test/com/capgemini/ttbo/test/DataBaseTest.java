package com.capgemini.ttbo.test;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.ttbo.dao.ITrainDao;
import com.capgemini.ttbo.dao.TrainDaoImpl;
import com.capgemini.ttbo.exception.BookingException;
import com.capgemini.ttbo.util.DBUtil;

public class DataBaseTest {
	static ITrainDao daotest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daotest = new TrainDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----code Starting DBConnection Test Case ----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws DonorException
	 **/
	@Test
	public void test() throws BookingException {
		Connection dbCon = DBUtil.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----Sab test Khatam----");
		daotest = null;
		dbCon = null;
	}



}
