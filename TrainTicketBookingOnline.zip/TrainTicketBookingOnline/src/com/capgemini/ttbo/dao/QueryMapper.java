package com.capgemini.ttbo.dao;

public interface QueryMapper
{
	public static final String RETRIVE_ALL_TRAIN_DETAILS="SELECT trainId,trainType,fromStop,toStop,fare,availableSeats,dateOfJourney FROM TrainDetails";
	public static final String INSERT_INTO_BOOKING = "INSERT INTO BookingDetails VALUES(?,?,?,?) ";
	public static final String SEQUENCE_NEXT_VAL = "select Booking_Id_Seq.NEXTVAL FROM dual";
	public static final String UPDATE_NO_OF_SEATS_AVAILABLE  ="UPDATE TrainDetails SET availableSeats =(availableSeats-1) WHERE custId=?";
}
//CREATE TABLE BookingDetails(bookingId NUMBER PRIMARY KEY,custId VARCHAR2(10), trainId REFERENCES TrainDetails(trainId),noOfSeats Number);
//UPDATE TrainDetails SET quantity =(quantity-1) WHERE mobileid=?
//UPDATE TrainDetails SET availableSeats =(availableSeats-1) WHERE custId=?