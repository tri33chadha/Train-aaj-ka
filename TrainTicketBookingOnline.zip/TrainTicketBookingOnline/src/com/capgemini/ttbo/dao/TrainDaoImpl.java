package com.capgemini.ttbo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.ttbo.bean.BookingBean;
import com.capgemini.ttbo.bean.TrainBean;
import com.capgemini.ttbo.exception.BookingException;
import com.capgemini.ttbo.util.DBUtil;



public class TrainDaoImpl implements ITrainDao 
{
	Logger logger = Logger.getRootLogger();
	public TrainDaoImpl() 
	{

		PropertyConfigurator.configure("resources/log4j.properties");
	}
	Connection conn = null;
	ArrayList<TrainBean> trainBean;
	
	
	/*****************************************************************
	 *  - Method Name   	:retrieveTrainDetails()  
	 *  - Input Parameters 	:Nothing
	 *  - Return Type 		:ArrayList<TrainBean>
	 *  - Throws 			:-----------
	 *  - Author 			:KISHAN 
	 *  - Creation Date 	:02/05/2019
	 *******************************************************************/
	@Override
	public ArrayList<TrainBean> retrieveTrainDetails() 
	{
		// TODO Auto-generated method stub
		System.out.println("kishan");             // for checking purpose only
		trainBean = new ArrayList<TrainBean>();
		try 
		{
			conn = DBUtil.getConnection();
		}
		catch(BookingException be)
		{
			logger.error("Connection not Established");
			System.err.println("Connection not Established"+be.getMessage());
		}
		try 
		{
			
			PreparedStatement pst = conn.prepareStatement(QueryMapper.RETRIVE_ALL_TRAIN_DETAILS);
			ResultSet rstkishan = pst.executeQuery();
			
				while (rstkishan.next()) 
				{
					
				TrainBean trainBean1 = new TrainBean();
					trainBean1.setAvailableSeats(rstkishan.getInt("availableSeats"));
					//trainBean1.setDateOfJourney(rstkishan.getDate("dateOfJourney"));
					trainBean1.setFare(rstkishan.getInt("fare"));
					trainBean1.setFromStop(rstkishan.getString("fromStop"));
					trainBean1.setToStop(rstkishan.getString("toStop"));
					trainBean1.setTrainId(rstkishan.getInt("trainId"));
					trainBean1.setTrainType(rstkishan.getString("trainType"));
					//trainId,trainType,fromStop,toStop,fare,availableSeats,dateOfJourney FROM TrainDetails
				
					trainBean.add(trainBean1);
				}
			}
		catch(SQLException e)
		{
			logger.error("Sorry no train details found try after some time");
			System.err.println("Sorry no train details found try after some time");
		}
	
		
		return trainBean;
	}

	/*****************************************************************
	 *  - Method Name   	: bookTicket() 
	 *  - Input Parameters 	:Nothing
	 *  - Return Type 		:ArrayList<TrainBean>
	 *  - Throws 			:BookingException
	 *  - Author 			:KISHAN 
	 *  - Creation Date 	:02/05/2019
	 *******************************************************************/
	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException
	{
		int bId = generatePurchaseId();
		try 
		{
			conn = DBUtil.getConnection();
		}
		catch(BookingException be)
		{
			logger.error("Connection not Established");
			System.err.println("Connection not Established"+be.getMessage());
		}
		// TODO Auto-generated method stub
		try
		{
				try
				{
					
					PreparedStatement pst2 = conn.prepareStatement("SELECT availableSeats FROM TrainDetails");
					ResultSet rs =pst2.executeQuery();
					rs.next();
					int seats = rs.getInt(1);
					if((bookingBean.getNoOfSeats()>seats))
					{
						throw new BookingException();
					}
				}
				catch(BookingException be)
				{
					logger.error("Please select less no of seats bcz available seats are less");
					System.err.println("Please select less no of seats bcz available seats are less");
				}
				/*try
				{
					PreparedStatement pst3 = conn.prepareStatement("UPDATE TrainDetails SET availableSeats =(availableSeats-?) WHERE custId=?");
					pst3.setInt(1,bookingBean.getNoOfSeats());
					pst3.setString(2,bookingBean.getCustId());
					ResultSet rs =pst3.executeQuery();
					rs.next();
					int seats = rs.getInt(1);
					if((bookingBean.getNoOfSeats()>seats))
					{
						throw new BookingException();
					}
				}
				catch(BookingException be)
				{
					logger.error("Please select less no of seats bcz available seats are less");
					System.err.println("Please select less no of seats bcz available seats are less");
				}*/
			PreparedStatement pst1 = conn.prepareStatement(QueryMapper.INSERT_INTO_BOOKING);
			pst1.setLong(1,bId);
			pst1.setString(2,bookingBean.getCustId());
			pst1.setInt(3,bookingBean.getTrainId());
			pst1.setInt(4,bookingBean.getTrainId());

			int rows = pst1.executeUpdate();
		}
		catch(SQLException se)
		{
			logger.error("Sorry there is some problem,we regret for the inconviniece try after some time");
			System.err.println("Sorry there is some problem,we regret for the inconviniece try after some time");
		}
		
		return bId;
	}
	/*****************************************************************
	 *  - Method Name   	:generatePurchaseId() 
	 *  - Input Parameters 	:Nothing
	 *  - Return Type 		:Integer
	 *  - Throws 			:BookingException
	 *  - Author 			:KISHAN 
	 *  - Creation Date 	:02/05/2019
	 *******************************************************************/
	public int generatePurchaseId() throws BookingException
	{
		int bId = 0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(QueryMapper.SEQUENCE_NEXT_VAL);
			ResultSet rst  = pst.executeQuery();
			rst.next();
			bId = rst.getInt(1);
			
		} 
		catch (SQLException e) {
			//logger.error("Problem in generating purchase id");
			logger.error("Problem in generating purchase id");
			throw new BookingException("Problem in generating purchase id" + e.getMessage());
		}
		return bId;
		
	}

}
